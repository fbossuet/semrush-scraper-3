#!/usr/bin/env node

/**
 * 🔍 EXTRACTION DES IDs DE BOUTIQUES
 * 
 * Script pour extraire les IDs des boutiques depuis la page de liste TrendTrack
 * et les stocker dans la base de données pour permettre le mapping des IDs.
 */

const TrendTrackExtractor = require('./src/extractors/trendtrack-extractor.js');
const ShopRepository = require('./src/database/shop-repository.js');

class ShopIdExtractor {
  constructor() {
    this.extractor = null;
    this.shopRepo = null;
  }

  async init() {
    console.log('🚀 Initialisation de l\'extracteur d\'IDs...');
    
    try {
      // Initialiser le scraper
      this.extractor = new TrendTrackExtractor();
      await this.extractor.init();
      console.log('✅ Scraper initialisé');
      
      // Se connecter à TrendTrack
      await this.extractor.connect();
      console.log('✅ Connexion TrendTrack établie');
      
      // Initialiser le repository
      this.shopRepo = new ShopRepository();
      console.log('✅ Repository initialisé');
      
    } catch (error) {
      console.error('❌ Erreur d\'initialisation:', error.message);
      throw error;
    }
  }

  async extractShopIds() {
    console.log('\n🔍 === EXTRACTION DES IDs DE BOUTIQUES ===');
    
    try {
      // Naviguer vers la page de liste TrendTrack
      console.log('🌐 Navigation vers la page de liste TrendTrack...');
      await this.extractor.navigateToListPage();
      
      // Extraire les données du tableau avec les IDs
      console.log('📋 Extraction des données du tableau...');
      const shopsData = await this.extractor.extractTableDataOnly();
      
      if (!shopsData || shopsData.length === 0) {
        console.log('⚠️ Aucune donnée extraite du tableau');
        return;
      }
      
      console.log(`✅ ${shopsData.length} boutiques extraites du tableau`);
      
      // Afficher quelques exemples d'IDs
      const sampleShops = shopsData.slice(0, 5);
      console.log('\n📋 Exemples d\'IDs extraits:');
      sampleShops.forEach((shop, index) => {
        console.log(`   ${index + 1}. ${shop.shopName} - ID: ${shop.externalId || shop.shopId || 'N/A'}`);
      });
      
      // Stocker les données dans la base
      console.log('\n💾 Stockage des données dans la base...');
      let storedCount = 0;
      let updatedCount = 0;
      
      for (const shopData of shopsData) {
        try {
          // Vérifier si la boutique existe déjà
          const existingShop = await this.shopRepo.findByUrl(shopData.shopUrl);
          
          if (existingShop) {
            // Mettre à jour l'ID externe
            if (shopData.externalId || shopData.shopId) {
              await this.shopRepo.updateExternalId(existingShop.id, shopData.externalId || shopData.shopId);
              updatedCount++;
              console.log(`✅ ID mis à jour pour: ${shopData.shopName} (${shopData.externalId || shopData.shopId})`);
            }
          } else {
            // Insérer une nouvelle boutique
            await this.shopRepo.insertTableData(shopData);
            storedCount++;
            console.log(`✅ Nouvelle boutique stockée: ${shopData.shopName} (${shopData.externalId || shopData.shopId})`);
          }
        } catch (error) {
          console.error(`❌ Erreur pour ${shopData.shopName}:`, error.message);
        }
      }
      
      console.log(`\n📊 === RÉSULTATS ===`);
      console.log(`✅ ${storedCount} nouvelles boutiques stockées`);
      console.log(`🔄 ${updatedCount} IDs mis à jour`);
      console.log(`📋 ${shopsData.length} boutiques traitées au total`);
      
      return {
        total: shopsData.length,
        stored: storedCount,
        updated: updatedCount
      };
      
    } catch (error) {
      console.error('❌ Erreur extraction des IDs:', error.message);
      throw error;
    }
  }

  async close() {
    if (this.extractor) {
      await this.extractor.close();
    }
  }
}

// 🚀 SCRIPT PRINCIPAL
async function main() {
  const extractor = new ShopIdExtractor();
  
  try {
    await extractor.init();
    const results = await extractor.extractShopIds();
    
    if (results) {
      console.log('\n🎉 === EXTRACTION TERMINÉE ===');
      console.log('✅ Les IDs des boutiques ont été extraits et stockés');
      console.log('✅ La solution de mapping des IDs peut maintenant être testée');
    }
    
  } catch (error) {
    console.error('❌ Erreur du script:', error);
  } finally {
    await extractor.close();
  }
}

// Lancer le script si exécuté directement
if (require.main === module) {
  main().catch(console.error);
}

module.exports = ShopIdExtractor;
