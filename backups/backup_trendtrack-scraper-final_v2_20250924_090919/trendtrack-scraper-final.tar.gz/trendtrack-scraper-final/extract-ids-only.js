#!/usr/bin/env node

/**
 * 🔍 EXTRACTION DES IDs UNIQUEMENT
 * 
 * Script pour extraire uniquement les IDs des boutiques depuis la page de liste TrendTrack
 * et les stocker dans la base de données.
 */

import { WebScraper } from './src/scraper.js';
import { TrendTrackExtractor } from './src/extractors/trendtrack-extractor.js';
import { DatabaseManager } from './src/database/database-manager.js';
import { ShopRepository } from './src/database/shop-repository.js';
import fs from 'fs';
import path from 'path';

const LOG_PROGRESS_FILE = 'logs/extract-ids-progress.log';

function logProgress(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  fs.appendFileSync(LOG_PROGRESS_FILE, line);
  console.log(msg);
}

// Nettoie le fichier de log au début
fs.writeFileSync(LOG_PROGRESS_FILE, '');

// EXTRACTION DES IDs UNIQUEMENT
async function extractIdsOnly(extractor, pageCount = 3) {
  logProgress(`🔍 EXTRACTION DES IDs: ${pageCount} pages...`);
  
  const allIds = [];
  
  for (let page = 1; page <= pageCount; page++) {
    logProgress(`➡️  Extraction page ${page}/${pageCount}...`);
    
    try {
      // Navigation vers la page
      const navSuccess = await extractor.navigateToTrendingShops(page);
      if (!navSuccess) {
        logProgress(`❌ Navigation échouée pour la page ${page}`);
        continue;
      }
      
      // Attendre que le tableau soit chargé
      await extractor.page.waitForSelector('tbody tr', { timeout: 60000 });
      
      // Récupérer toutes les lignes du tableau
      const rows = await extractor.page.locator('tbody tr').all();
      logProgress(`📊 ${rows.length} lignes trouvées dans le tableau`);
      
      let pageIds = 0;
      
      // Extraire chaque ligne avec focus sur les IDs
      for (let i = 0; i < rows.length; i++) {
        try {
          const row = rows[i];
          const cells = await row.locator('td').all();
          if (cells.length < 8) {
            continue;
          }

          const shopData = {};
          
          // EXTRACTION ID DE LA BOUTIQUE
          try {
            const rowHtml = await row.evaluate(el => el.outerHTML, { timeout: 10000 });
            const rowIdMatch = rowHtml.match(/<tr[^>]*id=["']([^"']+)["']/);
            const rowId = rowIdMatch ? rowIdMatch[1] : null;
            shopData.shopId = rowId;
            shopData.externalId = rowId;
            
            if (rowId) {
              logProgress(`✅ ID extrait: ${rowId}`);
              allIds.push(rowId);
              pageIds++;
            } else {
              logProgress(`⚠️ Aucun ID trouvé pour la ligne ${i + 1}`);
            }
          } catch (error) {
            logProgress(`❌ Erreur extraction ID ligne ${i + 1}: ${error.message}`);
          }
          
          // EXTRACTION INFO BOUTIQUE (pour identification)
          try {
            const shopInfoHtml = await cells[1].innerHTML();
            const shopNameMatch = shopInfoHtml.match(/<p class=\"text-sm font-semibold\">([^<]+)<\/p>/);
            shopData.shopName = shopNameMatch ? shopNameMatch[1].trim() : '';
            const shopUrlMatch = shopInfoHtml.match(/href=["']([^"']+)["']/);
            shopData.shopUrl = shopUrlMatch ? shopUrlMatch[1] : '';
            
            if (shopData.shopName && shopData.shopId) {
              logProgress(`📋 ${shopData.shopName} - ID: ${shopData.shopId}`);
            }
          } catch (error) {
            logProgress(`⚠️ Erreur extraction info boutique ligne ${i + 1}: ${error.message}`);
          }
          
        } catch (error) {
          logProgress(`❌ Erreur ligne ${i + 1}: ${error.message}`);
        }
      }
      
      logProgress(`✅ Page ${page}: ${pageIds} IDs extraits`);
      
    } catch (error) {
      logProgress(`❌ Erreur page ${page}: ${error.message}`);
    }
  }
  
  logProgress(`✅ EXTRACTION TERMINÉE: ${allIds.length} IDs extraits au total`);
  return allIds;
}

// SCRIPT PRINCIPAL
async function main() {
  logProgress('🚀 Démarrage de l\'extraction des IDs...');
  
  try {
    // Initialiser les composants
    const scraper = new WebScraper();
    const extractor = new TrendTrackExtractor();
    const dbManager = new DatabaseManager();
    const shopRepo = new ShopRepository(dbManager);
    
    // Initialiser le scraper
    await extractor.init();
    logProgress('✅ Scraper initialisé');
    
    // Se connecter à TrendTrack
    await extractor.connect();
    logProgress('✅ Connexion TrendTrack établie');
    
    // Extraire les IDs
    const extractedIds = await extractIdsOnly(extractor, 3);
    
    logProgress(`\n📊 === RÉSULTATS ===`);
    logProgress(`✅ ${extractedIds.length} IDs extraits`);
    
    if (extractedIds.length > 0) {
      logProgress('\n📋 Exemples d\'IDs extraits:');
      extractedIds.slice(0, 10).forEach((id, index) => {
        logProgress(`   ${index + 1}. ${id}`);
      });
      
      logProgress('\n🎉 Les IDs sont maintenant disponibles pour le mapping !');
      logProgress('💡 Vous pouvez maintenant tester la solution de mapping des IDs');
    } else {
      logProgress('\n⚠️ Aucun ID extrait - vérifiez la connexion et la structure de la page');
    }
    
  } catch (error) {
    logProgress(`❌ Erreur du script: ${error.message}`);
  } finally {
    // Fermer le scraper
    try {
      await extractor.close();
      logProgress('✅ Scraper fermé');
    } catch (error) {
      logProgress(`⚠️ Erreur fermeture scraper: ${error.message}`);
    }
  }
}

// Lancer le script
main().catch(console.error);
